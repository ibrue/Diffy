from .diffy_native import *

__doc__ = diffy_native.__doc__
if hasattr(diffy_native, "__all__"):
    __all__ = diffy_native.__all__